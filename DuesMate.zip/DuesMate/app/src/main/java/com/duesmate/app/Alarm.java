package com.duesmate.app;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import java.util.Calendar;

public class Alarm extends BroadcastReceiver {

    /** Schedules one check every day at about 9 AM. Safe to call repeatedly. */
    public static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, new Intent(c, Alarm.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, 9); t.set(Calendar.MINUTE, 0); t.set(Calendar.SECOND, 0);
        if (t.getTimeInMillis() < System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }

    @SuppressLint("MissingPermission")
    @Override public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) { schedule(c); return; }
        DB db = new DB(c);
        try {
            if (!db.get("rem", "1").equals("1")) return;
            long t = DB.today();
            int over = (int) db.num("SELECT COUNT(*) FROM payments p WHERE p.due<" + t + " AND " + DB.UNPAID);
            int soon = (int) db.num("SELECT COUNT(*) FROM payments p WHERE p.due>=" + t + " AND p.due<" + (t + 3 * 86400000L) + " AND " + DB.UNPAID);
            if (over + soon == 0) return;
            if (Build.VERSION.SDK_INT >= 26)
                ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE))
                        .createNotificationChannel(new NotificationChannel("dues", "Payment reminders", NotificationManager.IMPORTANCE_DEFAULT));
            NotificationManagerCompat nm = NotificationManagerCompat.from(c);
            if (!nm.areNotificationsEnabled()) return;
            PendingIntent pi = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            nm.notify(1, new NotificationCompat.Builder(c, "dues")
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle("DuesMate reminder")
                    .setContentText("Payments need attention: " + over + " overdue, " + soon + " due within 3 days.")
                    .setContentIntent(pi).setAutoCancel(true).build());
        } finally { db.close(); }
    }
}
