package com.duesmate.app;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    static int tab = 0;
    DB db;
    View[] pages = new View[4];
    EditText search;
    Spinner fil, sor;
    LinearLayout recent, custList, payList;

    @Override protected void onCreate(Bundle b) {
        db = new DB(getApplicationContext());
        AppCompatDelegate.setDefaultNightMode(db.get("dark", "0").equals("1") ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        pages[0] = findViewById(R.id.p0); pages[1] = findViewById(R.id.p1);
        pages[2] = findViewById(R.id.p2); pages[3] = findViewById(R.id.p3);
        recent = findViewById(R.id.h_recent); custList = findViewById(R.id.c_list); payList = findViewById(R.id.p_list);
        search = findViewById(R.id.c_search);
        fil = findViewById(R.id.fil); sor = findViewById(R.id.sor);
        fil.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"All", "Pending", "Paid", "Overdue"}));
        sor.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Sort: Due date", "Sort: Amount"}));
        AdapterView.OnItemSelectedListener sl = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> a, View v, int p, long id) { refresh(); }
            @Override public void onNothingSelected(AdapterView<?> a) { }
        };
        fil.setOnItemSelectedListener(sl); sor.setOnItemSelectedListener(sl);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) { refresh(); }
        });
        findViewById(R.id.h_add).setOnClickListener(v -> form(0, "", "", true, true));
        findViewById(R.id.c_add).setOnClickListener(v -> form(0, "", "", true, true));

        BottomNavigationView nav = findViewById(R.id.nav);
        nav.setOnItemSelectedListener(it -> {
            int id = it.getItemId();
            tab = id == R.id.n0 ? 0 : id == R.id.n1 ? 1 : id == R.id.n2 ? 2 : 3;
            show();
            return true;
        });
        nav.getMenu().getItem(tab).setChecked(true);

        // settings
        SwitchCompat sd = findViewById(R.id.s_dark), sr = findViewById(R.id.s_rem);
        sd.setChecked(db.get("dark", "0").equals("1")); sr.setChecked(db.get("rem", "1").equals("1"));
        sd.setOnCheckedChangeListener((v, on) -> {
            db.set("dark", on ? "1" : "0");
            AppCompatDelegate.setDefaultNightMode(on ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        });
        sr.setOnCheckedChangeListener((v, on) -> { db.set("rem", on ? "1" : "0"); if (on) askNotif(); });
        final EditText cur = findViewById(R.id.s_cur), cc = findViewById(R.id.s_cc);
        cur.setText(db.get("cur", "₹")); cc.setText(db.get("cc", ""));
        findViewById(R.id.s_save).setOnClickListener(v -> {
            db.set("cur", cur.getText().toString().trim());
            db.set("cc", cc.getText().toString().replaceAll("\\D", ""));
            toast("Saved"); refresh();
        });
        findViewById(R.id.s_export).setOnClickListener(v -> pick(1, "DuesMate_payments.csv", "text/csv"));
        findViewById(R.id.s_backup).setOnClickListener(v -> pick(2, "DuesMate_backup.db", "application/octet-stream"));
        findViewById(R.id.s_restore).setOnClickListener(v -> confirm("Restore will replace ALL current data. Continue?", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            startActivityForResult(i, 3);
        }));

        if (db.get("rem", "1").equals("1")) askNotif();
        Alarm.schedule(this);
        show(); refresh();
    }

    void askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9);
    }

    void show() { for (int i = 0; i < 4; i++) pages[i].setVisibility(i == tab ? View.VISIBLE : View.GONE); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    void txt(int id, String s) { ((TextView) findViewById(id)).setText(s); }
    static double num(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch (Exception x) { return 0; } }

    void confirm(String msg, Runnable r) {
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("Yes", (d, w) -> r.run()).setNegativeButton("Cancel", null).show();
    }

    void row(LinearLayout parent, String a, String b, String c, int color, View.OnClickListener l) {
        View v = getLayoutInflater().inflate(R.layout.row, parent, false);
        ((TextView) v.findViewById(R.id.t1)).setText(a);
        ((TextView) v.findViewById(R.id.t2)).setText(b);
        TextView t3 = v.findViewById(R.id.t3);
        t3.setText(c); t3.setTextColor(color);
        if (l != null) v.setOnClickListener(l);
        parent.addView(v);
    }

    // ---------- refresh all screens ----------
    void refresh() {
        long t = DB.today();
        int green = getColor(R.color.green), red = getColor(R.color.red), amber = getColor(R.color.amber);
        double total = db.num("SELECT IFNULL(SUM(amount),0) FROM payments"), rec = db.num("SELECT IFNULL(SUM(amount),0) FROM transactions");
        txt(R.id.h_pend, db.money(total - rec)); txt(R.id.h_rec, db.money(rec));
        txt(R.id.h_cust, "" + (int) db.num("SELECT COUNT(*) FROM customers"));
        txt(R.id.h_over, "" + (int) db.num("SELECT COUNT(*) FROM payments p WHERE p.due<" + t + " AND " + DB.UNPAID));
        txt(R.id.h_month, db.money(db.num("SELECT IFNULL(SUM(amount),0) FROM transactions WHERE ts>=" + DB.monthStart())));

        recent.removeAllViews();
        Cursor c = db.q("SELECT c.name,t.amount,t.ts FROM transactions t JOIN customers c ON c.id=t.customer_id ORDER BY t.ts DESC LIMIT 5");
        while (c.moveToNext()) row(recent, c.getString(0), DB.date(c.getLong(2)), "+" + db.money(c.getDouble(1)), green, null);
        if (c.getCount() == 0) row(recent, "No transactions yet", "", "", green, null);
        c.close();

        custList.removeAllViews();
        String s = "%" + search.getText().toString().trim() + "%";
        c = db.q("SELECT c.id,c.name,c.phone,IFNULL((SELECT SUM(p.amount) FROM payments p WHERE p.customer_id=c.id),0)-IFNULL((SELECT SUM(x.amount) FROM transactions x WHERE x.customer_id=c.id),0) FROM customers c WHERE c.name LIKE ? OR c.phone LIKE ? ORDER BY c.name COLLATE NOCASE", s, s);
        while (c.moveToNext()) {
            final long id = c.getLong(0); final String nm = c.getString(1), ph = c.getString(2); double bal = c.getDouble(3);
            row(custList, nm, ph, bal > 0.005 ? db.money(bal) : "Settled", bal > 0.005 ? amber : green, v -> custMenu(id, nm, ph));
        }
        c.close();

        payList.removeAllViews();
        String[] f = {"all", "pending", "paid", "overdue"};
        c = db.payments(f[fil.getSelectedItemPosition()], sor.getSelectedItemPosition() == 1 ? "amount" : "due");
        while (c.moveToNext()) {
            final long pid = c.getLong(0), cid = c.getLong(1), due = c.getLong(5);
            final String nm = c.getString(2), ph = c.getString(3), ds = c.getString(6);
            double amt = c.getDouble(4), paid = c.getDouble(7);
            final double rem = amt - paid;
            String st = rem <= 0.005 ? "Paid" : due < t ? "Overdue" : "Pending";
            int col = rem <= 0.005 ? green : due < t ? red : amber;
            row(payList, nm, st + " • Due " + DB.date(due) + "\nPaid " + db.money(paid) + " of " + db.money(amt) + (ds.isEmpty() ? "" : "\n" + ds),
                    rem > 0.005 ? db.money(rem) : "PAID", col, v -> payMenu(pid, nm, ph, rem, due));
        }
        c.close();

        StringBuilder sb = new StringBuilder();
        c = db.q("SELECT strftime('%Y-%m',ts/1000,'unixepoch','localtime'),SUM(amount) FROM transactions GROUP BY 1 ORDER BY 1 DESC LIMIT 12");
        while (c.moveToNext()) sb.append(c.getString(0)).append("   ").append(db.money(c.getDouble(1))).append("\n");
        c.close();
        txt(R.id.s_month, sb.length() == 0 ? "No payments received yet." : sb.toString().trim());
    }

    // ---------- menus ----------
    void custMenu(final long id, final String nm, final String ph) {
        String[] o = {"Add payment", "Edit customer", "Payment history", "Delete customer"};
        new AlertDialog.Builder(this).setTitle(nm).setItems(o, (d, w) -> {
            if (w == 0) form(id, nm, ph, false, true);
            else if (w == 1) form(id, nm, ph, true, false);
            else if (w == 2) history("customer_id", id, nm);
            else confirm("Delete this customer and all their payments?", () -> { db.del("customers", id); refresh(); });
        }).show();
    }

    void payMenu(final long pid, final String nm, final String ph, final double rem, final long due) {
        String[] o = {"Record payment (partial / full)", "Mark fully paid", "Send WhatsApp reminder", "History", "Delete payment"};
        new AlertDialog.Builder(this).setTitle(nm).setItems(o, (d, w) -> {
            if (w < 3 && rem <= 0.005) { toast("This payment is already fully paid"); return; }
            if (w == 0) amountDialog(pid, rem);
            else if (w == 1) { db.pay(pid, rem, UUID.randomUUID().toString()); refresh(); }
            else if (w == 2) remind(nm, ph, rem, due);
            else if (w == 3) history("payment_id", pid, nm);
            else confirm("Delete this payment record?", () -> { db.del("payments", pid); refresh(); });
        }).show();
    }

    void amountDialog(final long pid, double rem) {
        final EditText e = new EditText(this);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setHint("Amount (remaining " + db.money(rem) + ")");
        LinearLayout w = new LinearLayout(this);
        w.setPadding(48, 24, 48, 0);
        w.addView(e, new LinearLayout.LayoutParams(-1, -2));
        final String uid = UUID.randomUUID().toString();
        new AlertDialog.Builder(this).setTitle("Record payment").setView(w)
                .setPositiveButton("Save", (d, x) -> {
                    if (!db.pay(pid, num(e), uid)) toast("Enter a valid amount");
                    refresh();
                }).setNegativeButton("Cancel", null).show();
    }

    void history(String col, long id, String title) {
        StringBuilder sb = new StringBuilder();
        Cursor c;
        if (col.equals("customer_id")) {
            sb.append("BILLED\n");
            c = db.q("SELECT due,amount,descr FROM payments WHERE customer_id=? ORDER BY due DESC", "" + id);
            while (c.moveToNext()) sb.append(DB.date(c.getLong(0))).append("   ").append(db.money(c.getDouble(1))).append("  ").append(c.getString(2)).append("\n");
            c.close();
            sb.append("\nRECEIVED\n");
        }
        c = db.q("SELECT ts,amount FROM transactions WHERE " + col + "=? ORDER BY ts DESC", "" + id);
        while (c.moveToNext()) sb.append(DB.date(c.getLong(0))).append("   +").append(db.money(c.getDouble(1))).append("\n");
        if (c.getCount() == 0) sb.append("No payments received yet.");
        c.close();
        new AlertDialog.Builder(this).setTitle("History - " + title).setMessage(sb.toString().trim()).setPositiveButton("Close", null).show();
    }

    // ---------- add / edit form ----------
    void form(final long cid, String n, String p, final boolean person, final boolean pay) {
        View v = getLayoutInflater().inflate(R.layout.dialog_form, null);
        final EditText fn = v.findViewById(R.id.f_name), fp = v.findViewById(R.id.f_phone), fa = v.findViewById(R.id.f_amt),
                fd = v.findViewById(R.id.f_due), fx = v.findViewById(R.id.f_desc);
        v.findViewById(R.id.g_person).setVisibility(person ? View.VISIBLE : View.GONE);
        v.findViewById(R.id.g_pay).setVisibility(pay ? View.VISIBLE : View.GONE);
        fn.setText(n); fp.setText(p);
        final long[] due = {DB.today()};
        fd.setText(DB.date(due[0]));
        fd.setOnClickListener(x -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(due[0]);
            new DatePickerDialog(this, (dp, y, m, dd) -> {
                Calendar k = Calendar.getInstance();
                k.clear(); k.set(y, m, dd);
                due[0] = k.getTimeInMillis();
                fd.setText(DB.date(due[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        final AlertDialog d = new AlertDialog.Builder(this).setTitle(person && pay ? "New customer" : person ? "Edit customer" : "Add payment")
                .setView(v).setPositiveButton("Save", null).setNegativeButton("Cancel", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(y -> {
            String nm = fn.getText().toString().trim(), ph = fp.getText().toString().trim();
            double a = num(fa);
            if (person && (nm.isEmpty() || ph.isEmpty())) { toast("Name and mobile number are required"); return; }
            if (pay && !person && a <= 0) { toast("Enter an amount"); return; }
            long id = cid;
            if (person) { if (cid == 0) id = db.addCustomer(nm, ph); else db.editCustomer(cid, nm, ph); }
            if (pay && a > 0 && db.addPayment(id, a, due[0], fx.getText().toString().trim()) < 0) { toast("This payment already exists"); return; }
            d.dismiss(); refresh();
        }));
        d.show();
    }

    // ---------- WhatsApp (opens chat with prefilled text; user presses send) ----------
    void remind(String name, String phone, double rem, long due) {
        String msg = "Hello " + name + ", this is a gentle reminder that a payment of " + db.money(rem) + " is "
                + (due < DB.today() ? "overdue since " : "due on ") + DB.date(due) + ". Kindly pay at your convenience. Thank you!";
        String ph = phone.replaceAll("\\D", ""), cc = db.get("cc", "");
        if (ph.length() <= 10 && !cc.isEmpty()) ph = cc + ph.replaceFirst("^0+", "");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + ph + "?text=" + Uri.encode(msg))));
        } catch (Exception e) {
            Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg);
            startActivity(Intent.createChooser(s, "Share reminder"));
        }
    }

    // ---------- export / backup / restore ----------
    void pick(int rq, String name, String type) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type); i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, rq);
    }

    static String esc(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }

    String csv() {
        StringBuilder sb = new StringBuilder("Customer,Mobile,Description,Amount,Due date,Paid,Remaining,Status\n");
        long t = DB.today();
        Cursor c = db.payments("all", "due");
        while (c.moveToNext()) {
            double a = c.getDouble(4), p = c.getDouble(7); long due = c.getLong(5);
            sb.append(esc(c.getString(2))).append(',').append(esc(c.getString(3))).append(',').append(esc(c.getString(6))).append(',')
              .append(a).append(',').append(DB.date(due)).append(',').append(p).append(',').append(a - p).append(',')
              .append(a - p <= 0.005 ? "Paid" : due < t ? "Overdue" : "Pending").append('\n');
        }
        c.close();
        return sb.toString();
    }

    static void copy(InputStream i, OutputStream o) throws IOException {
        byte[] b = new byte[8192]; int n;
        while ((n = i.read(b)) > 0) o.write(b, 0, n);
        i.close(); o.close();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rs != RESULT_OK || d == null || d.getData() == null) return;
        Uri u = d.getData();
        try {
            if (rq == 1) {
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(csv().getBytes("UTF-8")); o.close();
                toast("CSV exported");
            } else if (rq == 2) {
                copy(new FileInputStream(getDatabasePath(DB.NAME)), getContentResolver().openOutputStream(u));
                toast("Backup saved");
            } else if (rq == 3) {
                File tmp = new File(getCacheDir(), "restore.db");
                copy(getContentResolver().openInputStream(u), new FileOutputStream(tmp));
                byte[] h = new byte[15];
                FileInputStream in = new FileInputStream(tmp);
                int n = in.read(h); in.close();
                if (n != 15 || !new String(h, "US-ASCII").equals("SQLite format 3")) { toast("Not a valid DuesMate backup"); return; }
                db.close();
                copy(new FileInputStream(tmp), new FileOutputStream(getDatabasePath(DB.NAME)));
                tmp.delete();
                toast("Data restored");
                recreate();
            }
        } catch (Exception e) { toast("Failed: " + e.getMessage()); }
    }
}
