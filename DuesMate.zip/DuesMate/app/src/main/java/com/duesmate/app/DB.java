package com.duesmate.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DB extends SQLiteOpenHelper {
    public static final String NAME = "duesmate.db";
    public static final String UNPAID = "p.amount-0.005>IFNULL((SELECT SUM(amount) FROM transactions WHERE payment_id=p.id),0)";

    public DB(Context c) { super(c, NAME, null, 1); }

    @Override public void onConfigure(SQLiteDatabase d) {
        d.disableWriteAheadLogging();
        d.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL,created INTEGER)");
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,amount REAL NOT NULL,due INTEGER NOT NULL,descr TEXT NOT NULL DEFAULT '',created INTEGER,UNIQUE(customer_id,amount,due,descr))");
        d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,uid TEXT NOT NULL UNIQUE,payment_id INTEGER NOT NULL REFERENCES payments(id) ON DELETE CASCADE,customer_id INTEGER NOT NULL,amount REAL NOT NULL,ts INTEGER)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase d, int o, int n) { }

    // ---------- helpers ----------
    public static long today() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
    public static long monthStart() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(today());
        c.set(Calendar.DAY_OF_MONTH, 1);
        return c.getTimeInMillis();
    }
    public static String date(long t) { return new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(new Date(t)); }
    public String money(double v) { return get("cur", "₹") + new DecimalFormat("#,##0.##").format(v); }

    public String get(String k, String def) {
        Cursor c = getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?", new String[]{k});
        try { return c.moveToFirst() ? c.getString(0) : def; } finally { c.close(); }
    }
    public void set(String k, String v) {
        ContentValues cv = new ContentValues();
        cv.put("k", k); cv.put("v", v);
        getWritableDatabase().insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public Cursor q(String sql, String... a) { return getReadableDatabase().rawQuery(sql, a); }
    public double num(String sql, String... a) {
        Cursor c = q(sql, a);
        try { return c.moveToFirst() ? c.getDouble(0) : 0; } finally { c.close(); }
    }

    // ---------- customers ----------
    public long addCustomer(String n, String p) {
        ContentValues cv = new ContentValues();
        cv.put("name", n); cv.put("phone", p); cv.put("created", System.currentTimeMillis());
        return getWritableDatabase().insert("customers", null, cv);
    }
    public void editCustomer(long id, String n, String p) {
        ContentValues cv = new ContentValues();
        cv.put("name", n); cv.put("phone", p);
        getWritableDatabase().update("customers", cv, "id=?", new String[]{"" + id});
    }
    public void del(String table, long id) { getWritableDatabase().delete(table, "id=?", new String[]{"" + id}); }

    // ---------- payments ----------
    /** returns -1 if an identical payment already exists (duplicate protection) */
    public long addPayment(long cid, double amt, long due, String descr) {
        ContentValues cv = new ContentValues();
        cv.put("customer_id", cid); cv.put("amount", amt); cv.put("due", due);
        cv.put("descr", descr); cv.put("created", System.currentTimeMillis());
        return getWritableDatabase().insert("payments", null, cv);
    }
    public double remaining(long pid) {
        return num("SELECT p.amount-IFNULL((SELECT SUM(amount) FROM transactions WHERE payment_id=p.id),0) FROM payments p WHERE p.id=?", "" + pid);
    }
    /** records a (partial) payment; uid makes the same submission impossible to save twice */
    public boolean pay(long pid, double amt, String uid) {
        double r = remaining(pid);
        if (amt <= 0 || r <= 0.005) return false;
        if (amt > r) amt = r;
        long cid = 0;
        Cursor c = q("SELECT customer_id FROM payments WHERE id=?", "" + pid);
        if (c.moveToFirst()) cid = c.getLong(0);
        c.close();
        ContentValues cv = new ContentValues();
        cv.put("uid", uid); cv.put("payment_id", pid); cv.put("customer_id", cid);
        cv.put("amount", amt); cv.put("ts", System.currentTimeMillis());
        return getWritableDatabase().insert("transactions", null, cv) != -1;
    }
    /** columns: 0 id,1 customer id,2 name,3 phone,4 amount,5 due,6 descr,7 paid */
    public Cursor payments(String filter, String sort) {
        String w = " WHERE 1=1";
        if (filter.equals("paid")) w += " AND paid>=amount-0.005";
        if (filter.equals("pending")) w += " AND paid<amount-0.005";
        if (filter.equals("overdue")) w += " AND paid<amount-0.005 AND due<" + today();
        return q("SELECT * FROM (SELECT p.id id,c.id cid,c.name name,c.phone phone,p.amount amount,p.due due,p.descr descr,"
                + "IFNULL((SELECT SUM(x.amount) FROM transactions x WHERE x.payment_id=p.id),0) paid "
                + "FROM payments p JOIN customers c ON c.id=p.customer_id)" + w
                + " ORDER BY " + (sort.equals("amount") ? "amount DESC" : "due ASC"));
    }
}
